This is Personal Use License Font
For more information visit:
https://imagifactory.blogspot.com/p/personal-use-license.html

You are free to use this font:
- For personal use only

Paypal account for donation: 
https://www.paypal.me/kurniawansart

This font also available for full version & commercial license, you can purchase it here:
https://thehungryjpeg.com/product/3869906-robot-font

If we find you violate this rule, we will sanction a fine.

Highly Appreciate,
Imagi Factory
